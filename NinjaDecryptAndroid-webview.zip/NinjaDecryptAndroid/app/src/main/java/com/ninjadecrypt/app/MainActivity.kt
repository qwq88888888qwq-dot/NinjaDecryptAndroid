package com.ninjadecrypt.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val siteUrl = "https://bypass.lat/BETA-BYPASS/?utm_source=chatgpt.com"
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var homePanel: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (savedInstanceState == null) loadSite() else {
            webView.restoreState(savedInstanceState)
            (homePanel.tag as? View)?.visibility = View.GONE
            webView.visibility = View.VISIBLE
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "忍者解密"
            textSize = 22f
            setTextColor(Color.rgb(25, 34, 53))
            typeface = Typeface.DEFAULT_BOLD
        }
        toolbar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val homeButton = Button(this).apply {
            text = "首页"
            isAllCaps = false
            setOnClickListener { showHome() }
        }
        toolbar.addView(homeButton)
        val refreshButton = Button(this).apply {
            text = "刷新"
            isAllCaps = false
            setOnClickListener { if (::webView.isInitialized && webView.visibility == View.VISIBLE) webView.reload() else loadSite() }
        }
        toolbar.addView(refreshButton)
        root.addView(toolbar)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        status = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(dp(12), dp(5), dp(12), dp(5))
            text = "测试版 · 尚未验证网站可用性"
        }
        root.addView(status)

        homePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
        }
        val homeScroll = android.widget.ScrollView(this).apply { addView(homePanel) }
        root.addView(homeScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        webView = WebView(this).apply {
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    status.text = if (newProgress < 100) "正在加载网页… $newProgress%" else "网页加载结束（不代表服务功能正常）"
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url ?: return false
                    if (url.scheme == "https" || url.scheme == "http") return false
                    return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true } catch (_: Exception) { true }
                }
                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    if (request?.isForMainFrame == true) {
                        status.text = "网页加载失败：请检查网络，或稍后重试。"
                    }
                }
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        homePanel.tag = homeScroll
    }

    private fun showHome() {
        webView.visibility = View.GONE
        (homePanel.tag as? View)?.visibility = View.VISIBLE
        homePanel.removeAllViews()
        val heading = TextView(this).apply {
            text = "测试版已启动"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(25, 34, 53))
            gravity = Gravity.CENTER
        }
        homePanel.addView(heading)
        val desc = TextView(this).apply {
            text = "这个版本用于测试应用能否启动，以及能否在应用内打开目标网站。网站本身的功能和可用性取决于远程服务。"
            textSize = 15f
            setTextColor(Color.rgb(75, 85, 105))
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(24))
        }
        homePanel.addView(desc)
        val open = Button(this).apply {
            text = "在应用内打开网站"
            isAllCaps = false
            setOnClickListener { loadSite() }
        }
        homePanel.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val disclaimer = TextView(this).apply {
            text = "说明：此测试版尚未移植网站的独立功能，也不会绕过网站的登录、卡密或服务器授权。"
            textSize = 13f
            setTextColor(Color.rgb(100, 108, 125))
            setPadding(0, dp(22), 0, 0)
        }
        homePanel.addView(disclaimer)
        status.text = "测试版 · 已准备就绪"
    }

    private fun loadSite() {
        (homePanel.tag as? View)?.visibility = View.GONE
        webView.visibility = View.VISIBLE
        status.text = "正在连接目标网站…"
        webView.loadUrl(siteUrl)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.visibility == View.VISIBLE && webView.canGoBack()) {
            webView.goBack()
        } else {
            showHome()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
