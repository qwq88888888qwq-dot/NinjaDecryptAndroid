# 忍者解密（测试版）

这是一个 Android 原生外壳测试项目，启动后自动在应用内 WebView 打开 `https://bypass.lat/BETA-BYPASS/?utm_source=chatgpt.com`。

## 当前版本能做什么
- 启动后自动加载目标网页。
- 顶部提供“首页”和“刷新”按钮；返回键可浏览网页历史。
- 显示网页加载进度和主页面加载错误提示。

## 尚未实现
- 没有把网站远程功能改造成独立原生功能。
- 不会绕过网站的登录、卡密或服务器授权。
- 尚未在真实手机上验证网站兼容性。

## 云端编译 APK
仓库内 `.github/workflows/build-apk.yml` 可通过 GitHub Actions 构建调试版 APK。将本项目文件上传到 GitHub 仓库后，打开仓库的 **Actions**，选择 **Build NinjaDecrypt APK**，点击 **Run workflow**。构建成功后打开对应运行记录，在 **Artifacts** 下载 `NinjaDecrypt-debug-apk`，解压得到 `app-debug.apk`。

## 本地构建
需要 JDK 17、Gradle 8.9 和 Android SDK Platform 35 / Build Tools 35.0.0，然后在项目根目录运行：

```bash
gradle assembleDebug
```

输出文件：`app/build/outputs/apk/debug/app-debug.apk`。
